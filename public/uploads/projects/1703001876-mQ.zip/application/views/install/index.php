<div class="card-header">
	Welcome
</div>
<div class="card-body">
	<p>This Setup Wizard will guide you through the installation of your new script. Smarty Scripts thanks you for your purchase and wishes success to your new project using our script.</p>
	<ul class="list-unstyled">
		<li><b>Script Name:</b> <?php echo SC_NAME; ?></li>
		<li><b>Script Version:</b> v<?php echo SC_VERSION; ?></li>
		<li><b>Official Site:</b> <a href="//www.smartyscripts.com" target="_blank">www.smartyscripts.com</a></li>
	</ul>
</div>
<div class="card-footer">
	<a href="<?php echo installRoute('install/step1');?>" class="btn btn-info">Continue</a>
</div>
